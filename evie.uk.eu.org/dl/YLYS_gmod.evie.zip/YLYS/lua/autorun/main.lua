--[[
    
   NotCatEvie - YLYS
   Addons by Evie Burrows
   evie.uk.eu.org
   twitter.com/NotCatEvie
    
    
]]--

-- Welcome and Load
print ('____ ____ _ ___ ___ ____ ____ ____ ____ _ _ ____ ____ ___ ____ _ _ _ _ _ _ _ ____')
print ('YLYS: Your Logo on Your Server')
print ('YLYS: © Copyright 2018 NotCatEvie (Evie ByCat) to (YLYS) - All rights reserved.')
print ('YLYS: You have a version named -> Early or v0.1')
print ('YLYS: >> Loading Config...')
include ('config/logo.lua')
print ('YLYS: >> Config is loaded')
print ('YLYS: >> Loading Addons')

-- Addons
if SERVER then
    util.AddNetworkString("YLYS_logo")

    hook.Add("PlayerInitialSpawn", "YLYS_logo", function(ply)
        if not ply:IsValid() then return end

        net.Start("YLYS_logo")
        net.Send(ply)
    end)
else
    net.Receive("YLYS_logo", function()
        local frame = vgui.Create("DFrame")
        frame:SetSize(YLYS.WidthPics, YLYS.HeightPics) -- Dimensions
        frame:SetPos(ScrW() - frame:GetWide() - YLYS.PosPics, YLYS.Pos2Pics) -- Positions
        frame:SetTitle("")
        frame:ShowCloseButton(false)
        frame.Paint = function(self, w, h)
        end

        local html = vgui.Create("HTML", frame)
        html:SetSize(frame:GetWide(), frame:GetTall())
        html:SetPos(0, 0)
        html:OpenURL(YLYS.URLPics) -- URL for logo
    end)
end

-- Loaded
print ('YLYS: >> Addons is loaded')
print ('____ ____ _ ___ ___ ____ ____ ____ ____ _ _ ____ ____ ___ ____ _ _ _ _ _ _ _ ____')



