--[[
    
   NotCatEvie - YLYS (Free-Early)
   Addons by Evie Burrows
   evie.uk.eu.org - evie.uk.eu.org/addon.gm_ylys.phtml
   twitter.com/NotCatEvie
    
    
]]--

AddCSLuaFile()
YLYS = {}

-- URL
YLYS.URLPics = "https://s.evie.uk.eu.org/gmod.evie.uk.eu.org/img/logo.JPG" -- URL for your avatar on your host. (Ex: http(s)://you.com/YLYS/logo.png)
-- Dimensions
YLYS.WidthPics = 400 -- Default: 50
YLYS.HeightPics = 400 -- Default: 50
-- Positions
YLYS.PosPics = 15 -- Default: 15
YLYS.Pos2Pics = 15 -- Default: 15
